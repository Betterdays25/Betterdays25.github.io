# Better Days CRM (100% Free & Self-Hosted in Replit)

This CRM setup runs **NocoDB directly inside Replit**, providing a free-for-life solution for Better Days Inc.

## ✅ Included Features
- Youth & Adult Participant Records
- Consent & Release Log
- Volunteer Data
- Attendance Tracking
- Compliance Logs (Incidents, Grievances)

## 🚀 How to Use
1. Upload this project as a Replit.
2. It will auto-start NocoDB (open port 8080).
3. Access your CRM at the generated Replit web URL.
4. Use the spreadsheet-like interface to manage data.
5. Export CSVs anytime for backup or reporting.

## 📂 Tables You Should Create
| Table Name | Description |
|------------|-------------|
| Participants | Name, DOB, Youth/Adult, Contact Info |
| Consents | Participant, Type (FERPA, Media), Date Signed, Notes |
| Volunteers | Name, Role, Availability, Background Check |
| Attendance | Participant, Program, Date |
| Compliance_Logs | Type, Date, Description, Resolution |

## 🔐 Optional Security
You can password-protect your NocoDB by setting environment variables in Replit:
- `NC_AUTH_JWT_SECRET` – secret for login token
- `NC_AUTH_BASIC_USER` – username
- `NC_AUTH_BASIC_PASS` – password

## 📘 More Info
NocoDB Docs: https://github.com/nocodb/nocodb

This solution is 100% free, portable, and future-proof.